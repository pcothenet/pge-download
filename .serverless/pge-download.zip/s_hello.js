
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'paulcothenet',
  applicationName: 'pge-download',
  appUid: 'zr34Kk852CCtQRCT2L',
  orgUid: 'tsS275R5sjrgpw0gc1',
  deploymentUid: '6c85efcd-8883-4513-903e-7243653852df',
  serviceName: 'pge-download',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.1.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'pge-download-dev-hello', timeout: 180 };

try {
  const userHandler = require('./lib/lambda.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}